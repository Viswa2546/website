products_list = {
        1: {
            "name": "car",
            "img": "car.jpg",
            "title": "Microsoft Surface Laptop 4 AMD Ryzen 5 4680U 13.5 inches Touchscreen Laptop"
        },
        2: {
            "name": "pen",
            "img": "pen.jpg",
            "title": "Croma Fire TV 80cm (32 Inch) HD Ready LED Smart TV (3 Years Warranty, Alexa Voice Assistant Remote, CREL7364, Black)"
        },
        3: {
            "name": "Mobile",
            "img": "mobile.jpg",
            "title": "VR Headset Compatible with iPhone & Android Phone - Universal Virtual Reality Goggles - Soft & Comfortable New 3D VR Glasses (Blue)"
        },
        4: {
            "name": "bag",
            "img": "handbag.jpg",
            "title": "2021 MG Hector CVT launched at Rs 16.52 Lakh"
        }
        
    }
  
empty_cart={}
for key,value in products_list.items():
    empty_cart[key]={
        'name':value['name']
        ,
        'quantity':0
    }
